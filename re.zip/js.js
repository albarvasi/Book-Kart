              function a()
              {
                 if (document.abc.firstname.value=="")
                    {
                      alert("enter a valid username");
                      document.abc.firstname.focus();
                       return false;
                    }
 		if (document.abc.email.value=="")
                    {
                      alert("enter a valid firstname
                      document.abc.Email.focus();
                       return false;
                    }
 		if (document.abc.lastname.value=="")
                    {
                      alert("enter a valid lastname");
                      document.abc.lastname.focus();
                       return false;
                    }
 		if (document.abc.username.value=="")
                    {
                      alert("enter a valid username");
                      document.abc.username.focus();
                       return false;
                    }
 		
		if (document.abc.firstname.value=="")
                    {
                      alert("enter a valid username");
                      document.abc.username.focus();
                       return false;
                    }
  		
		if (document.abc.password.value=="")
                    {
                      alert("enter a valid password");
                      document.abc.password.focus();
                       return false;
                    }
                 if (document.abc.University.value=="")
                    {
                      alert("enter a University or Shop name");
                      document.abc.university.focus();
                       return false;
                    }
		if(document.abc.male[0].checked==false && document.abc.male[1].checked==false)
                   {
                   alert("choose any one");
                   return false;
                   }
               